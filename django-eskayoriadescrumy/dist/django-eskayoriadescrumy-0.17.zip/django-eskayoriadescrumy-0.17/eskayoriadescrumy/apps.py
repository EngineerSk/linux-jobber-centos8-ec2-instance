from django.apps import AppConfig


class EskayoriadescrumyConfig(AppConfig):
    name = 'eskayoriadescrumy'
